export class Products
{
    id:string | undefined;
    product_Id: string | undefined;
    productName:string | undefined;
    entryDate:string | undefined;
    price:string | undefined;
}